

var strWebserviceURL = "https://skinmdnow.nuvolatek.net:4430/smnwsCust/skinmdservice.svc/";
var skinmdserviceURL = 'http://34.235.116.137:8080/frontend/public/api/';
var API_SERVER = 'http://34.235.116.137:8080/public/api/';//Backend server URL for case images upload
/* var skinmdserviceURL = "http://192.168.10.244:3001/api/"; 
var API_SERVER = "http://192.168.10.244:8000/api/"; //Backend server URL for case images upload */


var strGlobalErrorMessage = "Server Response Error";

jQuery.support.cors = true;

var app_ID = 1;
var footlink = "https://www.skinmdnow.com/";
var headlink = "https://www.skinmdnow.com/";
var termslink = "https://skinmdnow.nuvolatek.net:8080/CustomAppData/";
