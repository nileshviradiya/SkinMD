function savePatientAdditionalDetails() {
    jQuery('#page_loading').show();
    var AddHelper = {
        "patientAdditionalDetails": {
            "listCurrentMedicine": arrCurrentMedicine,
            "listDrugAllergies": arrAllergies,
            "listFamilyMedicalHistory": arrFamilyMedicalHistory,
            "listMedicalHistory": arrPatientMedicalHistory,
            "guidPharmacyId": window.localStorage.getItem("guidPharmacyId"),
            "strPharmacyName": jQuery("#txtPharmacyName").val(),
            "strPharmacyFax": ph_faxnum,
            "strErrorMessage": "",
            "guidAccountId": window.localStorage.getItem("guidAccountId"),
            "guidCaseId": window.localStorage.getItem("guidCaseId"),
            "guidCaseOwnerId": window.localStorage.getItem("guidDoctorId"),
            "app_ID": app_ID
        }
    };
    
    jQuery.ajaxSetup({
        headers: {
        'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
        }
    });

    jQuery.ajax({
        url: skinmdserviceURL + "savePatientAdditionalDetails",
        type: "POST",
        data: JSON.stringify(AddHelper),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function(result) {
            if (result.strErrorMessage == "" || result.strErrorMessage == null) {
                ChiefComplaintJS();
            } else {
                alert(strGlobalErrorMessage);

            }
            jQuery('#page_loading').hide();
        },
        error: function error(response) {
            jQuery('#page_loading').hide();

            alert(strGlobalErrorMessage);
        }
    });
}