<?php $__env->startSection('content'); ?>
<div id="content">
    <div id="modalContainer"> </div>
    <!--Login Page-->
    <div id="pageLogin" class="panel" data-modal="true">
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            
            <?php if(\Session::has('status')): ?>                
            <h3 style="color:green"><?php echo \Session::get('status'); ?></h3>
            <?php endif; ?>
            
            <?php if(\Session::has('warning')): ?>                
            <h3 style="color:red"><?php echo \Session::get('warning'); ?></h3>
            <?php endif; ?>
            
            <h3 class="h3St">Login Now</h3>
            <div class="loginDiv">
                <input id="username" type="text" class="jq-ui-forms" name="username" value="<?php echo e(old('username')); ?>" required autocomplete="username" autofocus placeholder="Username" onKeyPress="handleKeyPress(event);">
                    <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
                        <div class="errorDiv"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                <input id="password" type="password" class="form-control" name="password" required autocomplete="current-password"  placeholder="Password"  onKeyPress="handleKeyPress(event);">
                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                        <div class="errorDiv"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                <div>
                    <a href="javascript:;" onClick="gotoForgotPasswordScreen()" class="buttonLightColor lfbtys1" 
                style="position: relative;/* left: 33%;top: 52%; */">Forgot password?</a> 
                    <a href="javascript:;" class="buttonNext lfbtys" onClick="LoginMe(false)" style="position:relative;">Login</a>
                </div>
                <br clear="all">
                <br clear="all">
                <a href="javascript:;" class="registerBtn" onClick="openCreateAccountPage()" class="button">Create New Account</a>
                <br clear="all"> <br clear="all">
                <!-- <span class="backBtn"> 
                    <i class="fa fa-angle-left"></i>
                    <a class="phots-01">Back</a>
                </span> -->
                <br clear="all"> <br clear="all">
            </div>
        </form>
    </div>    
    <!--END-->

    <!--Forgot Password-->
    <div id="pageForgotPassword" class="panel" data-header="custom_header" style="display:none;">
        <h3 class="h3St">Reset Password</h3>
        <div class="forgotDiv">
            <!-- 
            <form method="POST" action="<?php echo e(route('password.email')); ?>" id="forgotPassword">
                <?php echo csrf_field(); ?> -->
                <div class="form-group row">
                    <div class="col-md-6">
                        <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="Enter Registered Email">

                        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
            <!-- </form> -->
            <div style="width:350px;">
                <a href="javascript:;" onClick="forgotPassword()" class="button forpast resetPassword">Reset my password</a>
                <span class="backBtn" style="cursor: pointer;"> 
                    <i class="fa fa-angle-left"></i>
                    <a class="phots-01" onclick="jQuery('#pageForgotPassword').hide(); jQuery('#pageLogin').show(); ">Back</a>
                </span>
            </div>
        </div>
    </div>
    <!--END-->

    <!--New user signup-->    
    <div id="pageCreateNew" class="panel" data-header="custom_header" style="padding:10px;display:none">
        <h3 style="color:#2D3446; font-family:'roboto', senserif">Create an Account</h3>
        <div style="margin:50px 0 0 310px;">
            <input type="text" id="txtNewFirstName" placeholder="First Name" class="jq-ui-forms" />
            <input type="text" id="txtNewMiddleName" placeholder="Middle Name" class="jq-ui-forms" />
            <input type="text" id="txtNewLastName" placeholder="Last Name" class="jq-ui-forms" />
            <div>
                <ul class="cretat">
                    <li class="firtset" style="width:120px!important;">
                        <select id="drpNewGender" style="width:150px!important;" data-native-menu="true">
                            <option value="0">Male</option>
                            <option value="1">Female</option>
                        </select>
                        <i class="fa fa-arrow-down" aria-hidden="true" style="      position: absolute;
                            top: 267px;
                            right: 585px;
                            color:#FFFFFF;
                            font-size: 15px;"></i>
                    </li>
                    <li style="padding:6px 0px 19px 18px;"> DOB:&nbsp; </li>
                    <li class="firtset1" style="width:80px;">
                        <input id="txtNewDateOfBirth" type='text' onClick="GetDate(this);" readonly placeholder="1980-12-01" class="jq-ui-forms" style="width:140px!important;" />
                    </li>
                </ul>
            </div>
            <br clear="all">
            <input type="tel" name="tel" id="txtNewPhone" value="" placeholder="Best Phone # (with area code)" class="jq-ui-forms" />
            <input type="text" id="txtNewUsername" placeholder="Username" class="jq-ui-forms" />
            <input type="email" id="txtNewEmail" value="" placeholder="Email" class="jq-ui-forms" />
            <input type="password" id="txtNewPassword" placeholder="Password" class="jq-ui-forms" />
            <input type="password" id="txtNewConfirmPassword" placeholder="Confirm Password" class="jq-ui-forms" />
            <div style="border:0px solid red; overflow:hidden;clear:both;">
                <label for="drpNewIsHealthProffesional" class="label_for" style="padding-top:8px; width:350px;">Are you a healthcare professional using <br />
                    Skin<sup>md</sup> Now for your patient?</label>
                <div style="width:353px !important;">
                    <select id="drpNewIsHealthProffesional" data-native-menu="false">
                        <option value="false">No</option>
                        <option value="true">Yes</option>
                    </select>
                    <i class="fa fa-arrow-down" aria-hidden="true" style=" 
                position: absolute;
                top: 584px;
                right: 352px;
                color: #FFFFFF;
                font-size: 15px;"></i>
                    <br clear="all" />
                </div>
            </div>
            <br clear="all" />
            <a href="javascript:;" onClick="addAccount()" class="buttonNext lfbtys2" style="cursor: pointer;
                background-color: #312769;
                color: #FFFFFF !important;
                float: left;
                font-family: 'roboto',senserif;
                font-weight: normal !important;
                padding: 8px 0;
                text-align: center;
                text-decoration: none;
                font-size: 14px;
                width: 115px;
                -moz-border-radius: 7px;
                -webkit-border-radius: 7px;
                border-radius: 7px;
                position: absolute;
                left: 40% !important;
                font-size: 17px;
                width: 189px;
                /* top: 9%; */
                display: inline-block;
                /* float: right; */
                bottom: 22%;
            }">Create New Account</a> <br clear="all" />
            <!--  <br clear="all"  /> -->
            <a href="javascript:;" onClick="cancelAccount()" class="buttonDelete lfbtys3">Cancel</a><br clear="all" />
            <br clear="all" />
        </div>
    </div>
    <!--END-->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.skin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SkinMDNow\frontend\resources\views/auth/login.blade.php ENDPATH**/ ?>