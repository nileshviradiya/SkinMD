<!DOCTYPE html>
<html>
<head>
    <title>Reset Password</title>
</head>

<body>
        <?php echo html_entity_decode($forgotContentValue); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\SkinMDNow\frontend\resources\views/emails/resetPassword.blade.php ENDPATH**/ ?>