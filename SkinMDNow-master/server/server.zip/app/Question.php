<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class question_answer_template extends Model
{
    const CREATED_AT = 'created_datetime';
    const UPDATED_AT = 'updated_datetime';
    
}
